/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.client.rendering.v1;

import net.fabricmc.fabric.impl.client.rendering.WrappedLayer;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.resources.ResourceLocation;

/**
 * A hud layer that has an identifier attached for use in {@link LayeredDrawerWrapper}.
 *
 * <p>The identifiers in this interface are the vanilla hud layers in the order they are drawn in.
 * The first layer is drawn first, which means it is at the bottom.
 * All vanilla layers except {@link #SLEEP} are in sub drawers and have a render condition attached ({@link net.minecraft.client.Options#hideGui}).
 * Operations relative to any layer will generally inherit that layer's render condition.
 * There is currently no mechanism to change the render condition of a layer.
 *
 * <p>For common use cases and more details on how this API deals with render condition, see {@link LayeredDrawerWrapper}.
 */
public interface IdentifiedLayer extends LayeredDraw.Layer {
	/**
	 * The identifier for the vanilla miscellaneous overlays (such as vignette, spyglass, and powder snow) layer.
	 */
	ResourceLocation MISC_OVERLAYS = ResourceLocation.withDefaultNamespace("misc_overlays");
	/**
	 * The identifier for the vanilla crosshair layer.
	 */
	ResourceLocation CROSSHAIR = ResourceLocation.withDefaultNamespace("crosshair");
	/**
	 * The identifier for the vanilla hotbar, spectator hud, experience bar, and status bars layer.
	 */
	ResourceLocation HOTBAR_AND_BARS = ResourceLocation.withDefaultNamespace("hotbar_and_bars");
	/**
	 * The identifier for the vanilla experience level layer.
	 */
	ResourceLocation EXPERIENCE_LEVEL = ResourceLocation.withDefaultNamespace("experience_level");
	/**
	 * The identifier for the vanilla status effects layer.
	 */
	ResourceLocation STATUS_EFFECTS = ResourceLocation.withDefaultNamespace("status_effects");
	/**
	 * The identifier for the vanilla boss bar layer.
	 */
	ResourceLocation BOSS_BAR = ResourceLocation.withDefaultNamespace("boss_bar");
	/**
	 * The identifier for the vanilla sleep overlay layer.
	 */
	ResourceLocation SLEEP = ResourceLocation.withDefaultNamespace("sleep");
	/**
	 * The identifier for the vanilla demo timer layer.
	 */
	ResourceLocation DEMO_TIMER = ResourceLocation.withDefaultNamespace("demo_timer");
	/**
	 * The identifier for the vanilla debug hud layer.
	 */
	ResourceLocation DEBUG = ResourceLocation.withDefaultNamespace("debug");
	/**
	 * The identifier for the vanilla scoreboard layer.
	 */
	ResourceLocation SCOREBOARD = ResourceLocation.withDefaultNamespace("scoreboard");
	/**
	 * The identifier for the vanilla overlay message layer.
	 */
	ResourceLocation OVERLAY_MESSAGE = ResourceLocation.withDefaultNamespace("overlay_message");
	/**
	 * The identifier for the vanilla title and subtitle layer.
	 *
	 * <p>Note that this is not the sound subtitles.
	 */
	ResourceLocation TITLE_AND_SUBTITLE = ResourceLocation.withDefaultNamespace("title_and_subtitle");
	/**
	 * The identifier for the vanilla chat layer.
	 */
	ResourceLocation CHAT = ResourceLocation.withDefaultNamespace("chat");
	/**
	 * The identifier for the vanilla player list layer.
	 */
	ResourceLocation PLAYER_LIST = ResourceLocation.withDefaultNamespace("player_list");
	/**
	 * The identifier for the vanilla sound subtitles layer.
	 */
	ResourceLocation SUBTITLES = ResourceLocation.withDefaultNamespace("subtitles");

	/**
	 * @return the identifier of the layer
	 */
	ResourceLocation id();

	/**
	 * Wraps a hud layer in an identified layer.
	 *
	 * @param id    the identifier to give the layer
	 * @param layer the layer to wrap
	 * @return the identified layer
	 */
	static IdentifiedLayer of(ResourceLocation id, LayeredDraw.Layer layer) {
		return new WrappedLayer(id, layer);
	}
}
