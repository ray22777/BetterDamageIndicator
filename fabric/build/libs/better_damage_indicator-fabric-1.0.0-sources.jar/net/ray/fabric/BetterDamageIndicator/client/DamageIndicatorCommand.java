package net.ray.fabric.BetterDamageIndicator.client;

import com.mojang.brigadier.CommandDispatcher;
import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.ray.BetterDamageIndicator.config.IndicatorConfig;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class DamageIndicatorCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("damageindicator")
                .executes(context -> {
                    class_310 client = class_310.method_1551();
                    if (client.field_1687 == null) return 0;
                    client.method_18858(() -> {
                        try {
                            Supplier<class_437> screenSupplier = AutoConfig.getConfigScreen(
                                    IndicatorConfig.class,
                                    client.field_1755
                            );
                            class_437 configScreen = screenSupplier.get();
                            client.method_1507(configScreen);

                        } catch (Exception e) {
                            System.err.println("Failed to open config: " + e);
                            client.field_1724.method_7353(
                                    class_2561.method_43470("Error while opening config"),
                                    false
                            );
                        }
                    });

                    return 1;
                })
        );
    }
}