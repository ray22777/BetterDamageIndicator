package net.ray.fabric.BetterDamageIndicator.client;

import com.mojang.brigadier.CommandDispatcher;
import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.ray.BetterDamageIndicator.config.IndicatorConfig;

import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class DamageIndicatorCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("damageindicator")
                .executes(context -> {
                    Minecraft client = Minecraft.getInstance();
                    if (client.level == null) return 0;
                    client.tell(() -> {
                        try {
                            Supplier<Screen> screenSupplier = AutoConfig.getConfigScreen(
                                    IndicatorConfig.class,
                                    client.screen
                            );
                            Screen configScreen = screenSupplier.get();
                            client.setScreen(configScreen);

                        } catch (Exception e) {
                            System.err.println("Failed to open config: " + e);
                            client.player.displayClientMessage(
                                    Component.literal("Error while opening config"),
                                    false
                            );
                        }
                    });

                    return 1;
                })
        );
    }
}