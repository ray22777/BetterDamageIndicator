package net.ray.BetterDamageIndicator;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.ray.BetterDamageIndicator.config.ConfigGetter;

import java.util.Iterator;
import java.util.Objects;

public class DamageTracker {
    public enum DAMAGE_SOURCE {
        SELF,
        PLAYER,
        ALL
    }

    private static final Int2ObjectMap<EntityData> ENTITY_DATA = new Int2ObjectOpenHashMap<>();
    private static final class_310 CLIENT = class_310.method_1551();

    private static class EntityData {
        float lastHealth;
        float lastMaxHealth;
        float damageToShow;
        float healingToShow;
        int showTicks;
        int lastSeenTick;
        boolean wasAlive;

        EntityData(float initialHealth, float maxHealth) {
            this.lastHealth = initialHealth;
            this.lastMaxHealth = maxHealth;
            this.lastSeenTick = getCurrentTick();
            this.wasAlive = true;
        }

        boolean update(class_1309 entity) {
            lastSeenTick = getCurrentTick();

            boolean isAlive = entity.method_5805();
            float currentHealth = entity.method_6032();
            float maxHealth = entity.method_6063();


            if (maxHealth > lastMaxHealth) {
                lastHealth = currentHealth;
                lastMaxHealth = maxHealth;
            }

            if (currentHealth < lastHealth) {
                float rawDamage = lastHealth - currentHealth;

                if (rawDamage > 0) {
                    damageToShow = rawDamage;
                    switch(ConfigGetter.iconfig.damageSource){
                        case ALL:
                            DamageRenderer.renderDamageIndicator(entity, rawDamage);
                            break;
                        case PLAYER:
                            if(Objects.requireNonNull(entity.method_6081()).method_5529() instanceof class_1657){
                                DamageRenderer.renderDamageIndicator(entity, rawDamage);
                            }
                            break;
                        case SELF:
                            if(Objects.requireNonNull(entity.method_6081()).method_5529() instanceof class_746){
                                DamageRenderer.renderDamageIndicator(entity, rawDamage);
                            }
                            break;
                    }
                }
                showTicks = 40;
            }
            else if (currentHealth > lastHealth) {
                float rawHealing = currentHealth - lastHealth;

                if (rawHealing > 0) {
                    healingToShow = rawHealing;
                    DamageRenderer.renderHealingIndicator(entity, rawHealing);
                }
                showTicks = 40;
            }
            lastHealth = currentHealth;

            wasAlive = isAlive;

            if (showTicks > 0) {
                showTicks--;
            }

            return (getCurrentTick() - lastSeenTick < 100) || showTicks > 0;
        }
    }

    public static void updateEntity(class_1309 entity) {
        if (!isValidEntity(entity)) return;

        int entityId = entity.method_5628();
        EntityData data = ENTITY_DATA.get(entityId);

        if (data == null) {
            data = new EntityData(entity.method_6032(), entity.method_6063());
            ENTITY_DATA.put(entityId, data);
        }

        if (!data.update(entity)) {
            ENTITY_DATA.remove(entityId);
        }
    }

    private static boolean isValidEntity(class_1309 entity) {
        if (!entity.method_73183().method_8608()) return false;
        if (CLIENT.field_1724 == null) return false;
        if (entity instanceof class_1531) return false;

        return entity.method_5739(CLIENT.field_1724) <= 64;
    }


    private static void cleanupStaleEntries() {
        int currentTick = getCurrentTick();
        Iterator<Int2ObjectMap.Entry<EntityData>> iterator = ENTITY_DATA.int2ObjectEntrySet().iterator();

        while (iterator.hasNext()) {
            Int2ObjectMap.Entry<EntityData> entry = iterator.next();
            EntityData data = entry.getValue();

            if ((currentTick - data.lastSeenTick > 100) && data.showTicks <= 0) {
                iterator.remove();
            }
        }
    }


    private static int getCurrentTick() {
        return CLIENT.field_1724 != null ? CLIENT.field_1724.field_6012 : 0;
    }
}