package net.ray.BetterDamageIndicator;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public class ComponentUtilsParser {

    public static class_2561 parseColorCodes(String text) {
        text = text.replace('&', '§');

        class_5250 result = class_2561.method_43470("");
        class_2583 currentStyle = class_2583.field_24360;
        StringBuilder currentText = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c == '§' && i + 1 < text.length()) {
                char code = text.charAt(++i);
                if (currentText.length() > 0) {
                    result.method_10852(class_2561.method_43470(currentText.toString())
                            .method_27696(currentStyle));
                    currentText.setLength(0);
                }
                class_124 formatting = class_124.method_544(code);
                if (formatting != null) {
                    if (formatting == class_124.field_1070) {
                        currentStyle = class_2583.field_24360;
                    } else {
                        currentStyle = currentStyle.method_27707(formatting);
                    }
                }
            } else {
                currentText.append(c);
            }
        }
        if (currentText.length() > 0) {
            result.method_10852(class_2561.method_43470(currentText.toString())
                    .method_27696(currentStyle));
        }

        return result;
    }
}