package net.ray.BetterDamageIndicator.forge;

import com.mojang.brigadier.CommandDispatcher;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.ray.BetterDamageIndicator.config.IndicatorConfig;

import java.util.function.Supplier;

// Use NeoForge's EventBusSubscriber
@Mod.EventBusSubscriber(modid = "better_damage_indicator", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DamageIndicatorCommand {

    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.m_82127_("damageindicator")
                .executes(context -> {
                    Minecraft client = Minecraft.m_91087_();
                    if (client.f_91073_ == null) return 0;

                    client.execute(() -> {
                        try {
                            Supplier<Screen> screenSupplier = AutoConfig.getConfigScreen(
                                    IndicatorConfig.class,
                                    client.f_91080_
                            );
                            Screen configScreen = screenSupplier.get();
                            client.m_91152_(configScreen);

                        } catch (Exception e) {
                            System.err.println("Failed to open config: " + e);
                            if (client.f_91074_ != null) {
                                client.f_91074_.m_5661_(
                                        Component.m_237113_("Error while opening config"),
                                        false
                                );
                            }
                        }
                    });

                    return 1;
                })
        );
    }
}